
  # Halaman Utama Aplikasi Surat

  This is a code bundle for Halaman Utama Aplikasi Surat. The original project is available at https://www.figma.com/design/MHUztS254TzWG86S7JS7vK/Halaman-Utama-Aplikasi-Surat.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  