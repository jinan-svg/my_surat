import {
  Mail,
  Send,
  Archive,
  Bell,
  Menu,
  User,
} from "lucide-react";
import { StatsCard } from "./components/StatsCard";
import { MailTable } from "./components/MailTable";
import { QuickActions } from "./components/QuickActions";
import { Button } from "./components/ui/button";

export default function App() {
  return (
    <div
      className="min-h-screen"
      style={{ backgroundColor: "#FFF9F0" }}
    >
      {/* Header/Navbar */}
      <header
        className="sticky top-0 z-50 shadow-sm"
        style={{ backgroundColor: "#DD9E59" }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="rounded-lg p-2 bg-white/10">
                <Mail className="size-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-white">
                  Sistem Surat Masuk/Keluar
                </h1>
                <p className="text-xs text-white/80">
                  Kelola surat dengan mudah
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="relative hover:bg-white/10 text-white"
              >
                <Bell className="size-5" />
                <span className="absolute top-1 right-1 size-2 bg-red-500 rounded-full"></span>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="hover:bg-white/10 text-white"
              >
                <User className="size-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="hover:bg-white/10 text-white md:hidden"
              >
                <Menu className="size-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">
            Selamat Datang! 👋
          </h2>
          <p className="text-gray-600">
            Hari ini,{" "}
            {new Date().toLocaleDateString("id-ID", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Surat"
            value="145"
            icon={Mail}
            trend="+12 dari bulan lalu"
            bgColor="#FFEDCE"
          />
          <StatsCard
            title="Surat Masuk"
            value="89"
            icon={Mail}
            trend="+8 hari ini"
            bgColor="#FFEDCE"
          />
          <StatsCard
            title="Surat Keluar"
            value="56"
            icon={Send}
            trend="+4 hari ini"
            bgColor="#FFEDCE"
          />
          <StatsCard
            title="Diarsipkan"
            value="127"
            icon={Archive}
            trend="Total arsip"
            bgColor="#FFEDCE"
          />
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <QuickActions />
        </div>

        {/* Recent Mail Table */}
        <MailTable />
      </main>

      {/* Footer */}
      <footer
        className="mt-12 py-6"
        style={{ backgroundColor: "#DD9E59" }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-white">
            © 2026 Sistem Surat Masuk/Keluar. Semua hak
            dilindungi.
          </p>
        </div>
      </footer>
    </div>
  );
}