import { FileText, Download, Eye } from 'lucide-react';
import { Button } from './ui/button';

interface Mail {
  id: string;
  number: string;
  subject: string;
  sender: string;
  date: string;
  type: 'incoming' | 'outgoing';
  status: 'read' | 'unread';
}

const mockMails: Mail[] = [
  {
    id: '1',
    number: 'SM/001/2026',
    subject: 'Undangan Rapat Koordinasi Bulanan',
    sender: 'Bagian Umum',
    date: '09 Apr 2026',
    type: 'incoming',
    status: 'unread',
  },
  {
    id: '2',
    number: 'SK/015/2026',
    subject: 'Laporan Kegiatan Triwulan I',
    sender: 'Bagian Keuangan',
    date: '08 Apr 2026',
    type: 'outgoing',
    status: 'read',
  },
  {
    id: '3',
    number: 'SM/002/2026',
    subject: 'Permohonan Data Kepegawaian',
    sender: 'Divisi SDM',
    date: '07 Apr 2026',
    type: 'incoming',
    status: 'read',
  },
  {
    id: '4',
    number: 'SK/016/2026',
    subject: 'Pengajuan Anggaran Proyek',
    sender: 'Tim Pengembangan',
    date: '06 Apr 2026',
    type: 'outgoing',
    status: 'read',
  },
  {
    id: '5',
    number: 'SM/003/2026',
    subject: 'Pemberitahuan Libur Nasional',
    sender: 'Bagian HRD',
    date: '05 Apr 2026',
    type: 'incoming',
    status: 'read',
  },
];

export function MailTable() {
  return (
    <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
      <div className="p-6 border-b border-gray-100">
        <h2 className="text-xl font-semibold" style={{ color: '#DD9E59' }}>
          Surat Terbaru
        </h2>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr style={{ backgroundColor: '#FFEDCE' }}>
              <th className="px-6 py-4 text-left text-sm font-medium text-gray-700">No. Surat</th>
              <th className="px-6 py-4 text-left text-sm font-medium text-gray-700">Perihal</th>
              <th className="px-6 py-4 text-left text-sm font-medium text-gray-700">Pengirim/Tujuan</th>
              <th className="px-6 py-4 text-left text-sm font-medium text-gray-700">Tanggal</th>
              <th className="px-6 py-4 text-left text-sm font-medium text-gray-700">Jenis</th>
              <th className="px-6 py-4 text-left text-sm font-medium text-gray-700">Status</th>
              <th className="px-6 py-4 text-left text-sm font-medium text-gray-700">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {mockMails.map((mail) => (
              <tr 
                key={mail.id} 
                className="hover:bg-gray-50 transition-colors duration-150"
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <FileText className="size-4" style={{ color: '#DD9E59' }} />
                    <span className="text-sm font-medium text-gray-900">{mail.number}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm text-gray-900 max-w-xs truncate">{mail.subject}</p>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">{mail.sender}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{mail.date}</td>
                <td className="px-6 py-4">
                  <span
                    className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium"
                    style={{
                      backgroundColor: mail.type === 'incoming' ? '#FFEDCE' : '#FFF5E6',
                      color: '#DD9E59',
                    }}
                  >
                    {mail.type === 'incoming' ? 'Masuk' : 'Keluar'}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span
                    className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium"
                    style={{
                      backgroundColor: mail.status === 'unread' ? '#DD9E59' : '#E5E7EB',
                      color: mail.status === 'unread' ? 'white' : '#6B7280',
                    }}
                  >
                    {mail.status === 'unread' ? 'Belum Dibaca' : 'Sudah Dibaca'}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="hover:bg-[#FFEDCE]"
                    >
                      <Eye className="size-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="hover:bg-[#FFEDCE]"
                    >
                      <Download className="size-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="p-4 border-t border-gray-100 flex items-center justify-between">
        <p className="text-sm text-gray-600">Menampilkan 5 dari 145 surat</p>
        <Button
          variant="outline"
          size="sm"
          className="border-[#DD9E59] text-[#DD9E59] hover:bg-[#FFEDCE]"
        >
          Lihat Semua
        </Button>
      </div>
    </div>
  );
}
