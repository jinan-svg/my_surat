import { FileText, Upload, Download, Archive, Search, Settings } from 'lucide-react';

const actions = [
  { id: 1, label: 'Buat Surat Baru', icon: FileText, color: '#DD9E59' },
  { id: 2, label: 'Upload Surat', icon: Upload, color: '#DD9E59' },
  { id: 3, label: 'Unduh Laporan', icon: Download, color: '#DD9E59' },
  { id: 4, label: 'Arsip Surat', icon: Archive, color: '#DD9E59' },
  { id: 5, label: 'Cari Surat', icon: Search, color: '#DD9E59' },
  { id: 6, label: 'Pengaturan', icon: Settings, color: '#DD9E59' },
];

export function QuickActions() {
  return (
    <div className="bg-white rounded-2xl shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-6" style={{ color: '#DD9E59' }}>
        Aksi Cepat
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <button
              key={action.id}
              className="flex flex-col items-center justify-center gap-3 p-6 rounded-xl transition-all duration-300 hover:shadow-md group"
              style={{ backgroundColor: '#FFEDCE' }}
            >
              <div
                className="rounded-full p-4 group-hover:scale-110 transition-transform duration-300"
                style={{ backgroundColor: action.color }}
              >
                <Icon className="size-6 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-700 text-center">
                {action.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
