import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  bgColor?: string;
}

export function StatsCard({ title, value, icon: Icon, trend, bgColor = '#FFEDCE' }: StatsCardProps) {
  return (
    <div 
      className="rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow duration-300"
      style={{ backgroundColor: bgColor }}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm opacity-70 mb-2">{title}</p>
          <h3 className="text-3xl font-semibold mb-1" style={{ color: '#DD9E59' }}>{value}</h3>
          {trend && (
            <p className="text-xs opacity-60">{trend}</p>
          )}
        </div>
        <div 
          className="rounded-xl p-3"
          style={{ backgroundColor: '#DD9E59' }}
        >
          <Icon className="size-6 text-white" />
        </div>
      </div>
    </div>
  );
}
